<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Panel</title>
</head>
<body>
    <main>
        <h1>Bienvenido, <?php echo e(auth()->user()->name); ?></h1>
        <p>Has iniciado sesión correctamente.</p>
        <p><a href="<?php echo e(route('profile.show')); ?>">Mi perfil</a></p>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit">Cerrar sesión</button>
        </form>
    </main>
</body>
</html>
<?php /**PATH C:\Users\Admin\Desktop\Trimestre 2026-III\vscode practica\Proyecto\proyecto4\resources\views/dashboard.blade.php ENDPATH**/ ?>