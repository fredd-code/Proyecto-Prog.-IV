<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mi perfil</title>
</head>
<body>
    <main>
        <h1>Mi perfil</h1>

        <?php if(session('status')): ?>
            <p role="status"><?php echo e(session('status')); ?></p>
        <?php endif; ?>

        <dl>
            <dt>Nombre</dt>
            <dd><?php echo e($user->name); ?></dd>
            <dt>Correo electrónico</dt>
            <dd><?php echo e($user->email); ?></dd>
        </dl>

        <p><a href="<?php echo e(route('profile.edit')); ?>">Editar perfil</a></p>
        <p><a href="<?php echo e(route('dashboard')); ?>">Volver al panel</a></p>

        <form method="POST" action="<?php echo e(route('profile.destroy')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <label for="delete-password">Confirma tu contraseña para eliminar la cuenta</label>
            <input id="delete-password" name="password" type="password" autocomplete="current-password" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p role="alert"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button type="submit">Eliminar mi cuenta</button>
        </form>
    </main>
</body>
</html>
<?php /**PATH C:\Users\Admin\Desktop\Trimestre 2026-III\vscode practica\Proyecto\proyecto4\resources\views/profile/show.blade.php ENDPATH**/ ?>